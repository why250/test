import numpy as np
import os
from datetime import datetime
import yaml
import csv
import io

__all__ = [
    "read_file_content",
    "calculate_gear_code",
    "calculate_dac_code",
    "load_yaml_config",
    "load_csv_config",
    "parse_config_file",
    "calculate_linearity_metrics",
    "save_linearity_results",
    "save_power_results",
]

def read_file_content(filepath):
    """
    Helper to read file content with multiple encoding attempts.
    """
    if not os.path.exists(filepath):
        return None
        
    encodings = ['utf-8-sig', 'utf-8', 'utf-16', 'utf-16-le', 'utf-16-be', 'gbk', 'gb18030', 'cp1252', 'latin-1']
    for enc in encodings:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                return f.read()
        except UnicodeDecodeError:
            continue
    
    # If all fail, try opening with errors='replace' as a last resort
    print(f"Warning: Could not decode {filepath} with standard encodings. using utf-8 with replace.")
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        return f.read()

def calculate_gear_code(gears):
    """
    Calculates the 16-bit register value for 4 channels' ranges.
    gears: list of 4 float values [range0, range1, range2, range3]
    Mapping: 2.5->14, 5.0->9, 10.0->10, 20.0->12
    """
    gear_to_code_map = {2.5: 14, 5.0: 9, 10.0: 10, 20.0: 12}
    if len(gears) != 4:
        return 0
    
    code0 = gear_to_code_map.get(float(gears[0]), 0)
    code1 = gear_to_code_map.get(float(gears[1]), 0)
    code2 = gear_to_code_map.get(float(gears[2]), 0)
    code3 = gear_to_code_map.get(float(gears[3]), 0)
    
    return (code3 << 12) | (code2 << 8) | (code1 << 4) | code0

def calculate_dac_code(voltage_range_str, desired_voltage):
    """
    Calculates the 16-bit DAC control code.
    voltage_range_str: '2.5', '5', '10', '20' (representing range)
    Let's assume Range N means [-N, N] for simplicity unless specified otherwise.
    """
    try:
        v_range = float(voltage_range_str)
        # Assumption: Range X means [-X, +X]
        min_v = -v_range
        max_v = v_range
        
        # Let's stick to [-Range, +Range] as a safe default for lab equipment handling negative voltages.
        
        desired_v = float(desired_voltage)
        
        if not (min_v <= desired_v <= max_v):
            # Try unipolar 0 to Range
            if 0 <= desired_v <= v_range:
                min_v = 0
                max_v = v_range
            else:
                 # If still out of range, warn but clamp or error?
                 # Requirement says "Calculates...".
                 pass

        dac_resolution = 2**16 - 1
        voltage_span = max_v - min_v
        
        if voltage_span == 0:
            return 0

        control_code = int(((desired_v - min_v) / voltage_span) * dac_resolution)
        return max(0, min(control_code, 65535)) # Clamp
    except ValueError:
        return 0

def load_yaml_config(filepath):
    """
    Parses YAML config files.
    Returns a list of dictionaries.
    """
    content = read_file_content(filepath)
    if content is None:
        return []
        
    try:
        return yaml.safe_load(content) or []
    except yaml.YAMLError as e:
        print(f"Error parsing YAML {filepath}: {e}")
        return []

def load_csv_config(filepath):
    """
    Parses CSV config files.
    Returns a list of dictionaries.
    """
    data = []
    if not os.path.exists(filepath):
        return data

    # Check for TSD encryption header first
    try:
        with open(filepath, 'rb') as f:
            header = f.read(20)
            if b'%TSD-Header' in header:
                print(f"CRITICAL ERROR: File {filepath} is encrypted by Titus Security (TSD).")
                print("The packaged application cannot decrypt this file.")
                print("Please save the file as PLAIN TEXT (remove protection) or decrypt it manually.")
                return []
    except:
        pass

    encodings = ['utf-8-sig', 'utf-8', 'gbk', 'gb18030', 'cp1252']
    
    for enc in encodings:
        try:
            with open(filepath, 'r', encoding=enc) as f:
                # Read all content first to handle potential read errors eagerly
                content = f.read()
                
                # Normalize newlines
                content = content.replace('\r\n', '\n').replace('\r', '\n')
                
                f_io = io.StringIO(content)
                reader = csv.DictReader(f_io)
                
                if reader.fieldnames:
                    # Clean fieldnames
                    fieldnames = [str(name).strip().lstrip('\ufeff') for name in reader.fieldnames]
                    
                    # Verify it looks like our config
                    if 'Channel' in fieldnames:
                        for row in reader:
                            clean_row = {k.strip(): v for k, v in row.items() if k}
                            if 'Channel' in clean_row:
                                data.append(clean_row)
                        return data
        except UnicodeDecodeError:
            continue
        except Exception as e:
            continue
    
    print(f"Warning: Could not read {filepath} with standard encodings or 'Channel' header missing.")
    return data

def parse_config_file(filepath):
    """
    Parses config files.
    Returns a list of lists/tuples.
    Handles lines like: "DAC0 5 0" or "(DP1, 1, 5.0, 1.0)"
    """
    data = []
    content = read_file_content(filepath)
    if content is None:
        return data
        
    f = io.StringIO(content)
    for line in f:
        line = line.strip()
        if not line or line.startswith('#') or line.startswith('//'):
            continue
        
        # Remove parentheses if present
        clean_line = line.replace('(', '').replace(')', '').replace(',', ' ')
        parts = clean_line.split()
        if parts:
            data.append(parts)
    return data

def calculate_linearity_metrics(input_values, measured_values):
    """
    Calculates Gain, Offset, DNL, INL.
    input_values: Theoretical/Set values (X)
    measured_values: Measured values (Y)
    """
    x = np.array(input_values, dtype=float)
    y = np.array(measured_values, dtype=float)
    
    if len(x) < 2:
        return None

    # 1. Gain & Offset (Linear Fit: y = Gain * x + Offset)
    A = np.vstack([x, np.ones(len(x))]).T
    gain, offset = np.linalg.lstsq(A, y, rcond=None)[0]
    
    # 2. INL (Integral Non-Linearity)
    # INL = (Vmeas - Vfit) / LSB_ideal
    # LSB_ideal can be estimated as (Max_Meas - Min_Meas) / (Num_Steps - 1) 
    # OR derived from the Step size of input * Gain.
    # Let's use the fitted line as reference.
    y_fit = gain * x + offset
    
    # Calculate LSB based on input step size * gain (expected output step)
    # Assuming uniform step size in input
    if len(x) > 1:
        avg_step = np.mean(np.diff(x))
        lsb_ideal = avg_step * gain
    else:
        lsb_ideal = 1.0 # Avoid div by zero
        
    if lsb_ideal == 0:
        lsb_ideal = 1e-9

    inl = (y - y_fit) / lsb_ideal
    
    # 3. DNL (Differential Non-Linearity)
    # DNL_i = ( (Vmeas_i - Vmeas_{i-1}) / LSB_ideal ) - 1
    dnl = np.zeros(len(y))
    # DNL is usually defined for steps. DNL[0] is usually 0 or undefined.
    for i in range(1, len(y)):
        step_meas = y[i] - y[i-1]
        dnl[i] = (step_meas / lsb_ideal) - 1
        
    # 4. Nonlinearity (% FSR)
    # Max deviation from fit / Full Scale Range
    # FSR = Max(y) - Min(y)
    fsr = np.max(y) - np.min(y)
    max_dev = np.max(np.abs(y - y_fit))
    
    nonlinearity_pct = 0.0
    if fsr > 0:
        nonlinearity_pct = (max_dev / fsr) * 100.0

    # Max INL / DNL
    max_inl = np.max(np.abs(inl))
    max_dnl = np.max(np.abs(dnl))

    return {
        "gain": gain,
        "offset": offset,
        "inl": inl, # Array
        "dnl": dnl, # Array
        "lsb_ideal": lsb_ideal,
        "nonlinearity_pct": nonlinearity_pct,
        "max_inl": np.max(np.abs(inl)), # Scalar
        "max_dnl": np.max(np.abs(dnl))  # Scalar
    }

def save_linearity_results(filename, input_vals, measured_vals, metrics):
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("                --- 传输曲线测试报告 ---\n")
        f.write(f"测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
        
        f.write("--- 分析结果 ---\n")
        f.write(f"Gain (Vout/Vin)               : {metrics['gain']:.6f}\n")
        f.write(f"Offset                        : {metrics['offset']:.6f} V\n")
        f.write(f"Nonlinearity                  : {metrics['nonlinearity_pct']:.4f} % FSR\n")
        f.write(f"Max INL                       : {metrics['max_inl']:.6f} LSB\n")
        f.write(f"Max DNL                       : {metrics['max_dnl']:.6f} LSB\n\n")
        
        f.write("--- 原始数据 ---\n")
        f.write(f"{'Vin (V)':<16}\t{'Vout (V)':<16}\n")
        f.write(f"{'-'*8:<16}\t{'-'*8:<16}\n")
        
        for i in range(len(input_vals)):
            f.write(f"{input_vals[i]:<16.4f}\t{measured_vals[i]:<16.6f}\n")

def save_power_results(results, final_status, site_id=None):
    """
    Saves power test results to a file.
    Follows SRP by separating IO from logic.
    """
    folder = "results/power_on_result"
    if site_id is not None:
        folder = f"{folder}/{site_id}"
        
    os.makedirs(folder, exist_ok=True)
    fname = f"{folder}/Power_on_result_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
    try:
        with open(fname, 'w') as f:
            f.write(f"Power Sequence Result - Final Status: {final_status}\n")
            f.write("="*50 + "\n")
            
            for i, step_data in enumerate(results):
                f.write(f"Step {i+1}:\n")
                for m in step_data:
                    status_str = f" ({m['status']})" if 'status' in m else ""
                    f.write(f"  {m['instrument']} CH{m['channel']}: {m['current']:.4f}A{status_str}\n")
                f.write("-" * 20 + "\n")
        return fname
    except Exception as e:
        print(f"Error saving results: {e}")
        return None
